const {app,BrowserWindow,session}=require('electron');
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'../..'),page=path.join(root,'src/tagcast/static/index.html');
const {contentPolicy}=require(path.join(root,'electron/security.cjs'));
app.setPath('userData',path.join(__dirname,'isolated-browser-profile'));
app.whenReady().then(async()=>{
 session.defaultSession.webRequest.onHeadersReceived((details,callback)=>callback({responseHeaders:{...details.responseHeaders,'Content-Security-Policy':[contentPolicy(fs.readFileSync(page,'utf8'))]}}));
 const win=new BrowserWindow({show:false,webPreferences:{sandbox:true,contextIsolation:true,nodeIntegration:false}});
 await win.loadFile(page);
 const result=await win.webContents.executeJavaScript(`(async()=>{
  const sink=document.createElement('section');document.body.append(sink);
  sink.innerHTML=accountCard({linked:{},preferences:{bitrate:'<img id="injected-image" src=x onerror="window.__injected=true">'}});
  const escaped=!sink.querySelector('#injected-image')&&sink.textContent.includes('<img');
  const fallback=document.createElement('div');fallback.className='has-art';document.body.append(fallback);
  const img=document.createElement('img');img.dataset.imageError='album';fallback.append(img);
  img.src='data:image/png;base64,invalid';
  await new Promise(r=>setTimeout(r,150));
  return {escaped,injected:window.__injected===true,removed:!img.isConnected,placeholder:!fallback.classList.contains('has-art')};
 })()`);
 assert.equal(result.escaped,true);assert.equal(result.injected,false);assert.equal(result.removed,true);assert.equal(result.placeholder,true);
 fs.writeFileSync(path.join(__dirname,'browser-safety.json'),JSON.stringify(result,null,2));win.destroy();app.quit();
}).catch(e=>{console.error(e);app.exit(1);});
