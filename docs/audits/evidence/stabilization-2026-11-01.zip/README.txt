Local stabilization evidence, 1 November 2026.

The Markdown report lists each fix, exact changed files, tests and limitations.
commits.txt and stabilization.patch describe the full local branch.
No changes were pushed, merged or released. Canonical main and the Apple Music worktree are unchanged.

JSON measurement reports are copied here; raw PCM/FLAC captures stay in the isolated worktree at /private/tmp/tagcast-stabilization-certifi-2026-11-01/build/stabilization. The copied evidence alone cannot rerun capture-length verification without those raw files.
The local ad-hoc macOS test archive remains in /private/tmp/tagcast-stabilization-certifi-2026-11-01/dist/packages. It is not an official release or an installed-app replacement.
